# forumphp

### Ce forum a été développé avec Symfony.

Afin de l'utiliser, vous devrez suivre ce readme.


Une fois le dossier téléchargé, lancez la commande suivante dans le répertoire forum-php :

`composer install`

Afin d'installer les dépendances de ce projet.

Ensuite, changez le fichier parameters.yml (*forumphp/forum-php/app/config/parameters.yml*) afin de correspondre à votre base de données et vos identifiants.

Une fois la base de données créée (toujours vide), lancez la commande suivante :

`php bin/console doctrine:schema:update --force`

Afin de créer les tables de la base de données ainsi que ses champs.

Pour avoir un jeux d'essais concernant le forum, importez les données fournies dans le script __symfony.sql__ présent dans le dossier forum-php

Les mots de passe des utilisateurs sont les mêmes que leurs pseudo __(exemple, pseudo : admin, mdp : admin)__

Il existe 3 comptes enregistrés, __admin, user, utilisateur__. (Tous 3 avec leur mdp correspondant comme ci-dessus)

Lancez votre serveur Symfony :

`php bin/console server:run`

## Et appréciez notre magnifique forum.
