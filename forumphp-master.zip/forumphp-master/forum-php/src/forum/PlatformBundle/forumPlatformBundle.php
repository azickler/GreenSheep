<?php

namespace forum\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class forumPlatformBundle extends Bundle
{
}
